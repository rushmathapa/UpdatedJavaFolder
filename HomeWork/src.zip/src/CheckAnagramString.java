import java.util.Scanner;

public class CheckAnagramString {

	public static void main(String[] args) {
		System.out.println("Enter any first words");
		Scanner scan = new Scanner(System.in);
		

	}

}
